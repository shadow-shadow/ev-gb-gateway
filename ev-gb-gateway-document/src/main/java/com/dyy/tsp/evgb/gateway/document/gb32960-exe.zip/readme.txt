1.解压jre
2.配置系统环境变量
变量值：EXE4J_JAVA_HOME=E:\exe\gb32960\jre
Path：添加%EXE4J_JAVA_HOME%\bin
3.启动gb32960.exe